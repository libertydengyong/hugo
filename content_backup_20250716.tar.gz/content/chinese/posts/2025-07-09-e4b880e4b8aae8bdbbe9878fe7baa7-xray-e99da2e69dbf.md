---
title: '一个轻量级 Xray 面板'
date: '2025-07-09T04:32:25+00:00'
author: ziyouhua
    - '8'
    - 'a:5:{s:8:"keywords";s:5:"74.51";s:9:"wordCount";s:1:"0";s:9:"linkCount";s:1:"0";s:12:"headingCount";s:1:"0";s:10:"mediaCount";s:1:"0";}'
    - '1'
    - '6'
categories:
    - vps工具
tags:
    - '轻量级 Xray 面板'
---

**轻量级 Xray 面板** bash &lt;(curl -Ls https://raw.githubusercontent.com/FranzKafkaYu/x-ui/master/install.sh) 项目来源: https://github.com/FranzKafkaYu/x-ui?tab=readme-ov-file#%E4%B8%80%E9%94%AE%E5%AE%89%E8%A3%85