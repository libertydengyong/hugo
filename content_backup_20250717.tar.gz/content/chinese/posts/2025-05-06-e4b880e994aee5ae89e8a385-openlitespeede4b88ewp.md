---
title: '一键安装 OpenLiteSpeed与WP'
date: '2025-05-06T04:00:43+00:00'
author: ziyouhua
    - '1'
categories:
    - '一键安装 OpenLiteSpeed'
tags:
    - OpenLiteSpeed与wp
---

一键安装 OpenLiteSpeed与WP 运行wget https://raw.githubusercontent.com/litespeedtech/ols1clk/master/ols1clk.sh &amp;&amp; bash ols1clk.sh 或 bash &lt;( curl -k https://raw.githubusercontent.com/litespeedtech/ols1clk/master/ols1clk.sh ) 安装 WordPress: bash &lt;( curl -k https://raw.githubusercontent.com/litespeedtech/ols1clk/master/ols1clk.sh ) -w